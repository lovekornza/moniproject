import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { InsertRoomPage } from './insert-room';

@NgModule({
  declarations: [
    InsertRoomPage,
  ],
  imports: [
    IonicPageModule.forChild(InsertRoomPage),
  ],
})
export class InsertRoomPageModule {}
